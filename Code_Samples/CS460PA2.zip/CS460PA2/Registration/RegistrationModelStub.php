<?php

	class RegStub{
		public function addPerson($usr, $pwd, $eml, $fname, $lname, $bday, $htown, $cad, $edu){
			//echo "IT WORKS";
		
			return "Registration successful.";
		}
	
	}
?>