//
//  ViewController.swift
//  ConnectTheDots
//
//  Created by Paavan Chopra on 7/18/15.
//  Copyright (c) 2015 ConstantTherapy. All rights reserved.
//

import UIKit

extension Array {
    
    func contains <T where T:
        Equatable> (obj: T) -> Bool {
            return self.filter({ $0 as? T == obj}).count>0
    }
}

extension Array {
    func find (includedElement: T -> Bool) -> Int? {
        for (idx, element) in enumerate(self) {
            if includedElement(element) {
                return idx
            }
        }
        return nil
    }
}






class ViewController: UIViewController {
    
    var lastPoint = CGPoint.zeroPoint
    var red: CGFloat = 0.0
    var green: CGFloat = 0.0
    var blue: CGFloat = 0.0
    var brushWidth: CGFloat = 10.0
    var opacity: CGFloat = 1.0
    var swiped = false
    
    
    
    
    var temp = [Int](count: 5, repeatedValue: 0) //keeps track of pressed buttons
    var x = [CGFloat](count: 6, repeatedValue: 0) //saves coordinates of buttons
    var y = [CGFloat](count: 6, repeatedValue: 0)
    
    
    var counter = 0
    var prev = CGPoint.zeroPoint
    var prevButton : UIButton = UIButton ()
    var buttonArray = [UIButton]()
    var buttonLocalArray = [CGPoint] ()
    var buttonRoundArray = [CGPoint] ()
    
    var imageSize : CGSize = CGSize()
    var imageView : UIImageView = UIImageView ()

    @IBOutlet weak var mainImageView: UIImageView!
    
    @IBOutlet weak var tempImageView: UIImageView!
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        swiped = false
        if let touch = touches.first as? UITouch {
            lastPoint = touch.locationInView(self.view)
        }
    }
    
    func drawLineFrom(fromPoint: CGPoint, toPoint: CGPoint) {
        
        var check = CGPoint(x: roundToTens(fromPoint.x),y: roundToTens(fromPoint.y))
        
        
        if (self.buttonRoundArray.contains(CGPoint(x: roundToTens(fromPoint.x),y: roundToTens(fromPoint.y)))){
            
            
            //update temp array based on counter
            if (self.counter<5){
                
                
                if (self.temp.contains(Int(find(buttonRoundArray, check)!) + 1) == false){
                    
                    //draw line
                    self.temp[self.counter] = Int(find(buttonRoundArray, check)!) + 1
                    
                    
                    self.prev = check
                    
                    self.counter++
                }
            }
            
            
        }
        
        var check2 = CGPoint(x: roundToTens(toPoint.x),y: roundToTens(toPoint.y))
        
        
        if (self.buttonRoundArray.contains(CGPoint(x: roundToTens(toPoint.x),y: roundToTens(toPoint.y)))){
            
            
            //update temp array based on counter
            if (self.counter<5){
                
                
                
                
                if (self.temp.contains(Int(find(buttonRoundArray, check2)!) + 1) == false){
                    
                    //draw line
                    self.temp[self.counter] = Int(find(buttonRoundArray, check2)!) + 1
                    
                    
                    self.prev = check2
                    
                    self.counter++
                }
            }
            
        }
        println(self.temp)
        
        
        
        // 1
        UIGraphicsBeginImageContext(view.frame.size)
        let context = UIGraphicsGetCurrentContext()
        tempImageView.image?.drawInRect(CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height))
        
        // 2
        CGContextMoveToPoint(context, fromPoint.x, fromPoint.y)
        CGContextAddLineToPoint(context, toPoint.x, toPoint.y)
        
        // 3
        CGContextSetLineCap(context, kCGLineCapRound)
        CGContextSetLineWidth(context, brushWidth)
        CGContextSetRGBStrokeColor(context, red, green, blue, 1.0)
        CGContextSetBlendMode(context, kCGBlendModeNormal)
        
        // 4
        CGContextStrokePath(context)
        
        // 5
        tempImageView.image = UIGraphicsGetImageFromCurrentImageContext()
        tempImageView.alpha = opacity
        UIGraphicsEndImageContext()
        
    }
    
    override func touchesMoved(touches: Set<NSObject>, withEvent event: UIEvent) {
        // 6
        swiped = true
        if let touch = touches.first as? UITouch {
            let currentPoint = touch.locationInView(view)
            drawLineFrom(lastPoint, toPoint: currentPoint)
            
            // 7
            lastPoint = currentPoint
        }
    }
    
    override func touchesEnded(touches: Set<NSObject>, withEvent event: UIEvent) {
        
        if !swiped {
            // draw a single point
            drawLineFrom(lastPoint, toPoint: lastPoint)
        }
        
        // Merge tempImageView into mainImageView
        UIGraphicsBeginImageContext(mainImageView.frame.size)
        mainImageView.image?.drawInRect(CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height), blendMode: kCGBlendModeNormal, alpha: 1.0)
        tempImageView.image?.drawInRect(CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height), blendMode: kCGBlendModeNormal, alpha: opacity)
        mainImageView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        tempImageView.image = nil
        var elf = checker()
        
        if (elf == true){
            
            var label = UILabel(frame: CGRectMake(0, 0, 200, 21))
            label.center = CGPointMake(160, 284)
            label.textAlignment = NSTextAlignment.Center
            label.text = "Success!"
            self.view.addSubview(label)
            
        }
        else {
            
            mainImageView.image = nil
            
        }
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        //create buttons
        for var index = 1; index < 6; ++index {
            
            let button   = UIButton.buttonWithType(UIButtonType.System) as! UIButton
            button.frame = CGRectMake(160, 100, 50, 50)
            button.layer.cornerRadius = 0.5 * button.bounds.size.width
            button.backgroundColor = UIColor.greenColor()
            button.setTitle(String(index), forState: UIControlState.Normal)
            
            button.enabled = false
            
            
            //button.addTarget(self, action: "buttonAction:", forControlEvents: UIControlEvents.TouchUpInside)
            button.tag = index
            
            let buttonWidth = button.frame.width
            let buttonHeight = button.frame.height
            
            // Find the width and height of the enclosing view
            let viewWidth = self.view.frame.size.width
            let viewHeight = self.view.frame.size.height
            
            // Compute width and height of the area to contain the button's center
            let xwidth = viewWidth - buttonWidth
            let yheight = viewHeight - buttonHeight
            
            // Generate a random x and y offset
            let xoffset = CGFloat(arc4random_uniform(UInt32(xwidth)))
            let yoffset = CGFloat(arc4random_uniform(UInt32(yheight)))
            
            // Offset the button's center by the random offsets.
            button.center.x = xoffset + buttonWidth / 2
            button.center.y = yoffset + buttonHeight / 2
            self.x[index] = button.center.x  //save coordinates
            
            self.y[index] = button.center.y
            self.buttonArray.append(button)
            
            
            self.buttonLocalArray.append(CGPoint(x: button.center.x, y: button.center.y))
            
            self.buttonRoundArray.append(CGPoint(x: roundToTens(button.center.x), y: roundToTens(button.center.y)))
            
            
            
            self.view.addSubview(button)
        }
        
        println(self.buttonRoundArray)
        
        
        
    }
    
    func roundToTens(x : CGFloat) -> CGFloat {
        return 50 * CGFloat(Int(round(x / 50.0)))
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //function checks the view to see if its right
    func checker() -> Bool {
        var check = [1,2,3,4,5]
        
        if (self.counter == 5){
            println(self.temp)
            println(check)
            if (self.temp==check){
                
                println("success")
                return true
            }
            else {
                
                println("fail")
                self.temp = [Int](count: 5, repeatedValue: 0)
                self.counter=0
                
                
                println(self.temp)
                return false
            }
            
            
        }
        else {
            
            println("fail")
            self.temp = [Int](count: 5, repeatedValue: 0)
            self.counter=0
            
            
            println(self.temp)
            
            return false
            
        }
        
        
    }
    
    
}

