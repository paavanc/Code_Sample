//
//  ViewController.swift
//  ConnectTheDots
//
//  Created by Paavan Chopra on 7/18/15.
//  Copyright (c) 2015 ConstantTherapy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //class constants for swipe
    var lastPoint = CGPoint.zeroPoint
    var red: CGFloat = 0.0
    var green: CGFloat = 0.0
    var blue: CGFloat = 0.0
    var brushWidth: CGFloat = 10.0
    var opacity: CGFloat = 1.0
    var swiped = false
    
    //class constants
    var temp = [Int](count: 5, repeatedValue: 0)
    var x = [CGFloat](count: 6, repeatedValue: 0)
    var y = [CGFloat](count: 6, repeatedValue: 0)
    var counter = 0
    var prev = 0
    var prevButton : UIButton = UIButton ()
    var buttonArray = [UIButton]()

    
    var imageSize : CGSize = CGSize()
    var imageView : UIImageView = UIImageView ()

    
    //touch begin methods
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        swiped = false
        if let touch = touches.first as? UITouch {
            lastPoint = touch.locationInView(self.view)
      
  
        }
    }
    
    override func touchesMoved(touches: Set<NSObject>, withEvent event: UIEvent) {
        // 6
        swiped = true
        if let touch = touches.first as? UITouch {
            let currentPoint = touch.locationInView(view)
            
            // 7
            lastPoint = currentPoint
            
            
        }
    }
    
    
    override func touchesEnded(touches: Set<NSObject>, withEvent event: UIEvent) {
        
        if !swiped {
            // draw a single point
            println("fail")
            self.temp = [Int](count: 5, repeatedValue: 0)
            self.counter=0
            self.prev=0
            clearView()
            viewDidLoad()
        }
        else {
            println(lastPoint)
            checker()
            
            
        }
        
        
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        //create buttons
        for var index = 1; index < 6; ++index {
            
             let button   = UIButton.buttonWithType(UIButtonType.System) as! UIButton
            button.frame = CGRectMake(160, 100, 50, 50)
            button.layer.cornerRadius = 0.5 * button.bounds.size.width
             button.backgroundColor = UIColor.greenColor()
            button.setTitle(String(index), forState: UIControlState.Normal)
           
            button.addTarget(self, action: "buttonAction:", forControlEvents: UIControlEvents.AllEvents)
            button.tag = index
            
            let buttonWidth = button.frame.width
            let buttonHeight = button.frame.height
            
            // Find the width and height of the enclosing view
            let viewWidth = self.view.frame.size.width
            let viewHeight = self.view.frame.size.height
            
            // Compute width and height of the area to contain the button's center
            let xwidth = viewWidth - buttonWidth
            let yheight = viewHeight - buttonHeight
            
            // Generate a random x and y offset
            let xoffset = CGFloat(arc4random_uniform(UInt32(xwidth)))
            let yoffset = CGFloat(arc4random_uniform(UInt32(yheight)))
            
            // Offset the button's center by the random offsets.
            button.center.x = xoffset + buttonWidth / 2
            button.center.y = yoffset + buttonHeight / 2
            self.x[index] = button.center.x
            
            self.y[index] = button.center.y
            self.buttonArray.append(button)
            
            self.view.addSubview(button)

            
        }
        
        
    
        
        
    }
    func clearView(){
        
  view.subviews.map({ $0.removeFromSuperview() })
    }
    
    //method that draws the lines
    //takes previous and current dot
    func drawCustomImage(size: CGSize, current: Int, previous: Int) -> UIImage {
        // Setup our context
        let bounds = CGRect(origin: CGPoint.zeroPoint, size: size)
        let opaque = false
        let scale: CGFloat = 0
        UIGraphicsBeginImageContextWithOptions(size, opaque, scale)
        let context = UIGraphicsGetCurrentContext()
        
        // Setup complete, do drawing here
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        CGContextSetLineWidth(context, 2.0)
        
        CGContextStrokeRect(context, bounds)
        
        CGContextBeginPath(context)
        CGContextMoveToPoint(context, self.x[previous], self.y[previous])
        CGContextAddLineToPoint(context, self.x[current], self.y[current])

        CGContextStrokePath(context)

        
        // Drawing complete, retrieve the finished image and cleanup
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    //function checks the view to see if its right
    func checker(){
        var check = [1,2,3,4,5]
        
        if (self.counter == 5){
            println(self.temp)
            println(check)
            if (self.temp==check){
                
                println("success")
            }
            else {
                
                println("fail")
                self.temp = [Int](count: 5, repeatedValue: 0)
                self.counter=0
                self.prev=0
                clearView()
                viewDidLoad()
                println(self.temp)
            }
            
            
        }
        else {
            
            println("fail")
            self.temp = [Int](count: 5, repeatedValue: 0)
            self.counter=0
            self.prev=0
            clearView()
            viewDidLoad()
            println(self.temp)
            
        }
        
        
    }
    
    //function thats called once a butotn is hit
    func buttonAction(sender:UIButton!)
    {
    
        //initialize imageview
        self.imageSize = CGSize(width: self.view.frame.size.width, height: self.view.frame.size.height)
        self.imageView = UIImageView(frame: CGRect(origin: CGPoint(x: self.view.frame.origin.x, y: self.view.frame.origin.y), size: self.imageSize))
        self.view.addSubview(self.imageView)
       
      
        
        
        
        
      
        //update temp array based on counter
        if (self.counter<5){
            
       
           
            if(Int(sender.tag) == Int(self.prev)){
                println("SAME")
            }
            if (Int(sender.tag) != Int(self.prev)){
       
       //draw line
        self.temp[self.counter] = sender.tag
                if(self.counter > 0){
                self.prevButton = sender
                let image = drawCustomImage(self.imageSize, current: Int(sender.tag), previous: Int(self.prev))
                self.imageView.image = image
                
            }
            
            self.prev = Int(sender.tag)
          
                self.counter++
            }
        }
        

        
        
       // println(sender.titleLabel!.text)
        //println("1")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

