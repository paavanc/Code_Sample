//
//  ViewController.swift
//  ConnectTheDots
//
//  Created by Paavan Chopra on 7/18/15.
//  Copyright (c) 2015 ConstantTherapy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //class constants
    var lastPoint = CGPoint.zeroPoint
    var red: CGFloat = 0.0
    var green: CGFloat = 0.0
    var blue: CGFloat = 0.0
    var brushWidth: CGFloat = 10.0
    var opacity: CGFloat = 1.0
    var swiped = false
    
    
    var temp = [Int](count: 5, repeatedValue: 0) //keeps track of pressed buttons
    var x = [CGFloat](count: 6, repeatedValue: 0) //saves coordinates of buttons
    var y = [CGFloat](count: 6, repeatedValue: 0)
    var counter = 0
    var prev = 0
    var prevButton : UIButton = UIButton ()
    

    var imageSize : CGSize = CGSize()
    var imageView : UIImageView = UIImageView ()
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        //create buttons
        for var index = 1; index < 6; ++index {
            
            let button   = UIButton.buttonWithType(UIButtonType.System) as! UIButton
            button.frame = CGRectMake(160, 100, 50, 50)
            button.layer.cornerRadius = 0.5 * button.bounds.size.width
            button.backgroundColor = UIColor.greenColor()
            button.setTitle(String(index), forState: UIControlState.Normal)
            
            button.addTarget(self, action: "buttonAction:", forControlEvents: UIControlEvents.TouchUpInside)
            button.tag = index
            
            let buttonWidth = button.frame.width
            let buttonHeight = button.frame.height
            
            // Find the width and height of the enclosing view
            let viewWidth = self.view.frame.size.width
            let viewHeight = self.view.frame.size.height
            
            // Compute width and height of the area to contain the button's center
            let xwidth = viewWidth - buttonWidth
            let yheight = viewHeight - buttonHeight
            
            // Generate a random x and y offset
            let xoffset = CGFloat(arc4random_uniform(UInt32(xwidth)))
            let yoffset = CGFloat(arc4random_uniform(UInt32(yheight)))
            
            // Offset the button's center by the random offsets.
            button.center.x = xoffset + buttonWidth / 2
            button.center.y = yoffset + buttonHeight / 2
            self.x[index] = button.center.x  //save coordinates
            
            self.y[index] = button.center.y
            
            self.view.addSubview(button)
            
            
        }
        
        
        
        
        
    }
    //clear all subviews
    func clearView(){
        
        view.subviews.map({ $0.removeFromSuperview() })
    }
    
    //draw lines from old to new dot
    func drawCustomImage(size: CGSize, current: Int, previous: Int) -> UIImage {
        // Setup our context
        let bounds = CGRect(origin: CGPoint.zeroPoint, size: size)
        let opaque = false
        let scale: CGFloat = 0
        UIGraphicsBeginImageContextWithOptions(size, opaque, scale)
        let context = UIGraphicsGetCurrentContext()
        
        // Setup complete, do drawing here
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        CGContextSetLineWidth(context, 2.0)
        
        CGContextStrokeRect(context, bounds)
        
        CGContextBeginPath(context)
        CGContextMoveToPoint(context, self.x[previous], self.y[previous])
        CGContextAddLineToPoint(context, self.x[current], self.y[current])
        
        CGContextStrokePath(context)
        
        
        // Drawing complete, retrieve the finished image and cleanup
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    
    //button that runs once a button is pressed
    func buttonAction(sender:UIButton!)
    {
        
        //initialize image view
        self.imageSize = CGSize(width: self.view.frame.size.width, height: self.view.frame.size.height)
        self.imageView = UIImageView(frame: CGRect(origin: CGPoint(x: self.view.frame.origin.x, y: self.view.frame.origin.y), size: self.imageSize))
        self.view.addSubview(self.imageView)
        
        
        
        
        //standard to see if buttons prssed in order
        var check = [1,2,3,4,5]
        
        //as long as counter less than five, all five buttons pressed keep going
        if (self.counter<5){
            
            
            //make sure the button pressed isnt the same one as before
            if(Int(sender.tag) == Int(self.prev)){
                println("SAME")
            }
            if (Int(sender.tag) != Int(self.prev)){
                //update temp array and draw arrow
                
                self.temp[self.counter] = sender.tag
                if(self.counter > 0){
                    self.prevButton = sender
                    let image = drawCustomImage(self.imageSize, current: Int(sender.tag), previous: Int(self.prev))
                    self.imageView.image = image
                    
                }
                
                self.prev = Int(sender.tag)
                
                self.counter++
            }
        }
        
        //once all buttons are pressed, check the order
        if (self.counter == 5){
            println(self.temp)
            println(check)
            if (self.temp==check){
                
                println("success")
            }
            else {
                //reset board if fail
                println("fail")
                self.temp = [Int](count: 5, repeatedValue: 0)
                self.counter=0
                self.prev=0
                clearView()
                viewDidLoad()
                println(self.temp)
            }
            
            
        }
        
        
        // println(sender.titleLabel!.text)
        //println("1")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

