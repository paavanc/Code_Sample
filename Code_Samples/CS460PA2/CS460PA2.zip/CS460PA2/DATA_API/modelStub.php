
<?php


class APIModel{


	}


	?>