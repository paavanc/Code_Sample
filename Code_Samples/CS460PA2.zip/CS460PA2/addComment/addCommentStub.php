<?php

class Model {
	function login($username, $password) {
		return "Teach Login Successful";
	}

}

