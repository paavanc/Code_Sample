//
//  ViewController.swift
//  Maze
//
//  Created by Paavan Chopra on 7/18/15.
//  Copyright (c) 2015 ConstantTherapy. All rights reserved.
//

import UIKit
import SpriteKit

/*

Algorithm for maze generation derived form here
http://rosettacode.org/wiki/Maze_generation

Assume maze starts in  top left hand corner and ends in the bottom right hand corner

*/

class ViewController: UIViewController {

    @IBOutlet weak var mazeScreen: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
      //  let imageSize = CGSize(width: 200, height: 200)
      //  let imageView = UIImageView(frame: CGRect(origin: CGPoint(x: 100, y: 100), size: imageSize))
     //   self.view.addSubview(imageView)
     //   let image = drawCustomImage(imageSize)
     //   imageView.image = image
        
        
        //number of rows and cols
      let x = 10
        let y = 11
        //lines to generate maze
       let maze = MazeGenerator(x, y)
        mazeScreen.numberOfLines = 33
        //print maze as a lable
        mazeScreen.font = UIFont(name: "Courier", size: 18.0)
     mazeScreen.text = maze.display() as String
    }

    //draws lines on a uiimage
    func drawCustomImage(size: CGSize) -> UIImage {
        // Setup our context
        let bounds = CGRect(origin: CGPoint.zeroPoint, size: size)
        let opaque = false
        let scale: CGFloat = 0
        UIGraphicsBeginImageContextWithOptions(size, opaque, scale)
        let context = UIGraphicsGetCurrentContext()
        
        // Setup complete, do drawing here
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        CGContextSetLineWidth(context, 2.0)
        
        CGContextStrokeRect(context, bounds)
        
        CGContextBeginPath(context)
        CGContextMoveToPoint(context, CGRectGetMinX(bounds), CGRectGetMinY(bounds))
        CGContextAddLineToPoint(context, CGRectGetMaxX(bounds), CGRectGetMaxY(bounds))
        CGContextMoveToPoint(context, CGRectGetMaxX(bounds), CGRectGetMinY(bounds))
        CGContextAddLineToPoint(context, CGRectGetMinX(bounds), CGRectGetMaxY(bounds))
        CGContextStrokePath(context)
        
        // Drawing complete, retrieve the finished image and cleanup
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


//class that determines direction of vector
class Direction {
    var vect:(Int, Int, Int)
    var bit:Int {
        let (bit, dx, dy) = vect
        return bit
    }
    
    var dx:Int {
        let (bit, dx, dy) = vect
        return dx
    }
    
    var dy:Int {
        let (bit, dx, dy) = vect
        return dy
    }
    
    var opposite:Direction {
        switch (vect) {
        case (1, 0, -1):
            return Direction(bit: 2, dx: 0, dy: 1)
        case (2, 0, 1):
            return Direction(bit: 1, dx: 0, dy: -1)
        case (4, 1, 0):
            return Direction(bit: 8, dx: -1, dy: 0)
        case (8, -1, 0):
            return Direction(bit: 4, dx: 1, dy: 0)
        default:
            return Direction(bit: 0, dx: 0, dy: 0)
        }
    }
    
    init(bit:Int, dx:Int, dy:Int) {
        self.vect = (bit, dx, dy)
    }
}

let N = Direction(bit: 1, dx: 0, dy: -1)
let S = Direction(bit: 2, dx: 0, dy: 1)
let E = Direction(bit: 4, dx: 1, dy: 0)
let W = Direction(bit: 8, dx: -1, dy: 0)

//class that generates maze
class MazeGenerator {
    let x:Int!
    let y:Int!
    var maze:[[Int]]!
    
    init(_ x:Int, _ y:Int) {
        self.x  = x
        self.y = y
        var col = [Int](count: y, repeatedValue: 0)
        self.maze = [[Int]](count: x, repeatedValue: col)
        generateMaze(0, 0)
    }
    
    //function that generates the maze..prints ascii characters based on maze gird
    func  display() ->NSString {
        //these variables build our string
        var grid = ""
        
        var temp = ""
        
        for i in 0..<y {
            // Draw top edge
            for j in 0..<x {
               temp = ((maze[j][i] & 1) == 0 ? "+---" : "+   ") //mask
                
                print((maze[j][i] & 1) == 0 ? "+---" : "+   ")
                
                grid = grid + temp
                
            }
            
             println("+")
            
            temp = ("+\n")
            grid = grid + temp
            
            // Draw left edge
            for j in 0..<x {
                print((maze[j][i] & 8) == 0 ? "|   " : "    ")
                temp = ((maze[j][i] & 8) == 0 ? "|   " : "    ")
                grid = grid + temp
            }
            println("|")
            temp = ("|\n")
            grid = grid + temp
        }
        
        //Draw bottom edge
        for j in 0..<x {
             print("+---")
            temp = ("+---")
            grid = grid + temp
        }
        println("+")
        temp = ("+")
        grid = grid + temp
        
        return grid
    }
    //generate maze
    func generateMaze(cx:Int, _ cy:Int) {
        var dirs = [N, S, E, W] as NSMutableArray
        for i in 0..<dirs.count {
            let x1 = Int(arc4random()) % dirs.count
            let x2 = Int(arc4random()) % dirs.count
            dirs.exchangeObjectAtIndex(x1, withObjectAtIndex: x2)
        }
        //fill in grid
        for dir in dirs {
            var dir = dir as! Direction
            let nx = cx + dir.dx
            let ny = cy + dir.dy
            if (between(nx, self.x) && between(ny, self.y) && (maze[nx][ny] == 0)) {
                maze[cx][cy] |= dir.bit
                maze[nx][ny] |= dir.opposite.bit
                generateMaze(nx, ny)
            }
            
        }
    }
    //helper function
    func between(v:Int, _ upper:Int) -> Bool {
        return (v >= 0) && (v < upper)
    }
}





